// $(function(){
// var temp=$("#temp").attr("value");
// $(".menu li").removeClass("curr");
// $(".menu li").eq(temp).addClass("curr") 
// })